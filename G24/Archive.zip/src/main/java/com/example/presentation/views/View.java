package com.example.presentation.views;

public interface View {
    public void display();
}
