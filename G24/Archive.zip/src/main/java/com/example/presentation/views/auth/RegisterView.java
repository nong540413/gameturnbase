package com.example.presentation.views.auth;

import com.example.presentation.views.View;

public class RegisterView implements View {
    public RegisterView() {}

    @Override
    public void display() {
        System.out.println("Register");
        System.out.println("----------------------");
    }
}
