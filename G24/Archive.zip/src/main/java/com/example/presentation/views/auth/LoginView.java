package com.example.presentation.views.auth;

import com.example.presentation.views.View;

public class LoginView implements View {
    public LoginView(){}

    @Override
    public void display() {
        System.out.println("Login");
        System.out.println("----------------------");
    }
}
