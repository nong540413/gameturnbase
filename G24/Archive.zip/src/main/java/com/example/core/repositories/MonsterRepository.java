package com.example.core.repositories;

import com.example.core.domain.abstracts.Monster;

import java.util.ArrayList;

public interface MonsterRepository {
    public ArrayList<Monster> getMonsters();
}
