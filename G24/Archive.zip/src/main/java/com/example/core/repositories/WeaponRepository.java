package com.example.core.repositories;

public interface WeaponRepository {

}