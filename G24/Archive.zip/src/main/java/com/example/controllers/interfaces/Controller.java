package com.example.controllers.interfaces;

public interface Controller {
    public Controller execute();
}
