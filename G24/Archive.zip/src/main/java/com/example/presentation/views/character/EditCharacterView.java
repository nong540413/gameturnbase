package com.example.presentation.views.character;

import com.example.presentation.views.View;

public class EditCharacterView implements View {

    @Override
    public void display() {
        System.out.println("Character Edited");
        System.out.println("----------------------");
        System.out.print("Name: ");
    }
}
